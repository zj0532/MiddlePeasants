<?php
use think\Route;
Route::post('/api/update','api/index/post_update');//管理员首页
Route::post('/api/trade','api/index/post_trade');//管理员首页

?>
