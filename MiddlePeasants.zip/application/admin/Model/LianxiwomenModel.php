<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/20 0020
 * Time: 10:48
 */

namespace app\admin\Model;


use think\Model;

class LianxiwomenModel extends Model
{
    // 设置当前模型对应的完整数据表名称
    protected $table = 'base_lianxiwomen';
}