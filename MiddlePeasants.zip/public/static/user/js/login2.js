$(document).ready(function(){
  $("#login_phone_cn_btn").on("click",function(){
    window.location.replace("/cn/user");
  });
});
