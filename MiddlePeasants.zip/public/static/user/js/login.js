$(document).ready(function(){
  $("#login_phone_en_btn").on("click",function(){
    window.location.replace("/en/user");
  });
});
